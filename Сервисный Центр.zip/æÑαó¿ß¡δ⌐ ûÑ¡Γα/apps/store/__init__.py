default_app_config = 'apps.store.apps.StoreConfig'
