default_app_config = 'apps.newsletter.apps.NewsletterConfig'
