default_app_config = 'apps.coupon.apps.CouponConfig'
