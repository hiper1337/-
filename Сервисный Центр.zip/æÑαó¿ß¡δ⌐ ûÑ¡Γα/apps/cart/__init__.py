default_app_config = 'apps.cart.apps.CartConfig'
